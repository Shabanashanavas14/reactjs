import React from "react";
import TodoWrapper from "./Components/TodoWrapper";
import './App.css';


function App() {
  return (
    <div className="App">
      <TodoWrapper />
    </div>
  );
}

export default App;
