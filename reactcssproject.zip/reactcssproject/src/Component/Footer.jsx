import React from 'react'
import './Footer.css'

export default function Footer() {
  return (
    <div>
        <footer>
        <p>&copy; 2025 Travel Explorer. All rights reserved.</p>
        <p>Email: travel123@gmail.com</p>
    </footer>
    
    </div>
  )
}
